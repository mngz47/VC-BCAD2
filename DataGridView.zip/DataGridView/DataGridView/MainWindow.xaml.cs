﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DataGridView
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

          

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            //validation - cannot be left out


            if (course_name.Text.Length == 0 || course_code.Text.Length == 0 || credits.Text.Length == 0)
            {
                MessageBox.Show("Fields Cannot Be Blank");
            }
            else
            {

                if (MessageBox.Show("Is the entry correct?", "Confirmation", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {

                    //pull textBox values -- pass them into DGV

                    Course course = new Course();
                    course.courseName= course_name.Text;    
                    course.courseCode= course_code.Text;
                    course.noCredits = credits.Text;
                    course.classHrs = class_hrs.Text;


                    _DATA_.Items.Add(course);


                }
            }
        }
    }
}
