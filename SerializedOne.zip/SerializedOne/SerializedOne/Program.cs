﻿// See https://aka.ms/new-console-template for more information

using System;
using System.Xml.Serialization;
using SerializedOne;

class Program

{

    static void Main(string[] args)
    {
        List<Person> list = new List<Person>();

        list.AddRange(new Person[]
        {
            new Person ("John", "Doe", 100),
            new Person ("Max", "Renna", 100),
            new Person ("Dan", "Rain", 100)
        });




        Stream stream = File.OpenWrite(Environment.CurrentDirectory + "\\firstserial.txt");
        XmlSerializer xml = new XmlSerializer(typeof(List<Person>));  
        xml.Serialize(stream, list);
        stream.Close(); 

    }


}




//Console.WriteLine("Hello, World!");
