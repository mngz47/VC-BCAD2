﻿
using PersonalBudget;
using System;
using System.Collections.Generic;

public class Program
{

    public static void Main(string[] arg) {
        
        Console.WriteLine("Personal Budget");

        Console.WriteLine("Gross monthly income");
        float gross_monthly_income = float.Parse(Console.ReadLine());

        Console.WriteLine("Estimated monthly tax");
        float monthly_tax = float.Parse(Console.ReadLine());

        Console.WriteLine("Total Expenditure");
        List<float> expenditure = new List<float>();

        Console.WriteLine("Groceries");
        expenditure.Add(float.Parse(Console.ReadLine()));

        Console.WriteLine("Water and lights");
        expenditure.Add(float.Parse(Console.ReadLine()));

        Console.WriteLine("Travel costs");
        expenditure.Add(float.Parse(Console.ReadLine()));

        Console.WriteLine("Cell phone and telephone");
        expenditure.Add(float.Parse(Console.ReadLine()));

        Console.WriteLine("Other expenses");
        expenditure.Add(float.Parse(Console.ReadLine()));

        Console.WriteLine("Property");
        Console.WriteLine("Rent(1)");
        float rental_amount = 0;
        Console.WriteLine("Buy(2)");
        float loan_repayment = 0;

        int mode = Int32.Parse(Console.ReadLine());

        if (mode == 1)
        {
            Console.WriteLine("Rental amount");
            rental_amount = float.Parse(Console.ReadLine());
        }
        else if(mode == 2)
        {

            HomeLoan hl = new HomeLoan();
            loan_repayment = hl.calculateLoan(gross_monthly_income);

        }


        float available_monthly_money = gross_monthly_income - monthly_tax - getTotalExpenditure(expenditure) - (mode == 1 ? rental_amount:loan_repayment);

        Console.WriteLine("Available Monthly Money : "+ available_monthly_money);

        Vehicle v = new Vehicle(gross_monthly_income, expenditure, (mode == 1 ? rental_amount : loan_repayment));

    }


   public static float getTotalExpenditure(List<float> expenditure)
    {
        float sum = 0;
        foreach (float a in expenditure)
        {
            sum += a;
        }
        return sum;
    }

}