﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BudgetPlannerWPF
{
    class Student
    {

        public string Name { get; set; }

        public string Surname { get; set; }

        public int StudentNumber { get; set; }

        int studentAge;

        public int Age
        {
            get
            {
                return studentAge;
            }
            set
            {
                if (value != studentAge)
                    studentAge = value;
            }

        }


    }
}
