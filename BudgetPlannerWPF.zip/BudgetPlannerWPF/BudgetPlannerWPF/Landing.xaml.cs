﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BudgetPlannerWPF
{
    /// <summary>
    /// Interaction logic for Landing.xaml
    /// </summary>
    public partial class Landing : Window
    {
        public Landing()
        {
            InitializeComponent();


            s.Name = "Mongezi";
            s.Surname = "Mafunda";
            s.StudentNumber = 454253;
            s.Age = 34;

            this.DataContext = s;
        }


        Student s = new Student();

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            string message = "\nName: " + s.Name +
                "\nSurname: " + s.Surname +
                "\nStudent Number: " + s.StudentNumber +
                "\nAge: " + s.Age;

            MessageBox.Show(message);


        }

    }
}
