﻿
using System.Windows;

namespace MenuControlProgram
{
    /// <summary>
    /// Interaction logic for PersonalBudget.xaml
    /// </summary>
    public partial class PersonalBudget : Window
    {
        public PersonalBudget()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {


            Program p = new Program();

            float gross_monthly_income = float.Parse(this.gross_monthly_income.Text);
            float monthly_tax = float.Parse(this.monthly_tax.Text);

            float groceries = float.Parse(this.groceries.Text);
            float water_lights = float.Parse(this.water_lights.Text);
            float travel_costs = float.Parse(this.travel_costs.Text);
            float phone = float.Parse(this.phone.Text);
            float other_expense = float.Parse(this.other_expense.Text);

            int property = ((bool)this.rent.IsChecked ? 1 : 2);

            p.startCalculation(this,gross_monthly_income, monthly_tax, groceries, water_lights, travel_costs, phone, other_expense, property);

            try { 
            string model = this.vehicle_model.Text;
            float vehicle_price = float.Parse(this.vehicle_price.Text);
            float vehicle_deposit = float.Parse(this.vehicle_deposit.Text);
            float vehicle_interest = float.Parse(this.vehicle_interest.Text);
            float vehicle_premium = float.Parse(this.vehicle_premium.Text);

            p.vehicleCalculation(gross_monthly_income, property, model, vehicle_price, vehicle_deposit, vehicle_interest, vehicle_premium);

            }
            catch (System.FormatException sfe)
            {}

           

        }
    }
}
