﻿using System;
using System.Collections.Generic;

public class Vehicle : Program
{
	public	Vehicle(float income,List<float> expenditure,float loanRepayment, string model, float price, float deposit, float interest, float premium)
	{

			float tmc = totalMonthlyCost(price+deposit,interest/100);

            if (income*0.75<(Program.getTotalExpenditure(expenditure)+loanRepayment+tmc))
            {
				
				Del handler = DelegateMethod;
				handler("Total expenses exceed 75% of your income");

        }
			printExpenses(expenditure);
	}


	public float totalMonthlyCost(float A,float i) //calculating total monthly cost
    {
		//A = P(1+ (i * n))
		return ((A) / (1+ (i * 5*12)));
	}

	public delegate void Del(string message); //Alert message feature - total expense limit

	public static void DelegateMethod(string message)
	{
		Console.BackgroundColor = ConsoleColor.Blue;
		System.Windows.MessageBox.Show(message);
		Console.ResetColor();
	}


	public void printExpenses(List<float> expenditure)
    { //Print expenses in descending order
		string data = ("Expenses in decsending order");

		Console.WriteLine();
		expenditure.Sort();
		expenditure.Reverse();

		foreach (var item in expenditure)
        {
			data += "\n" + item;
        }

		System.Windows.MessageBox.Show(data);

	}



}