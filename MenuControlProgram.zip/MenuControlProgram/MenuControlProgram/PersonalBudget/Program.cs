﻿
using MenuControlProgram;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;

public class Program 
{


   public  Program(MenuControlProgram.PersonalBudget pb, string rent, float gross_monthly_income, float monthly_tax, float groceries, float water_light, float travel_cost, float cell_phone, float other_expense, int property)
    {

        rental_repayment = float.Parse(rent);

        startCalculation(pb,gross_monthly_income, monthly_tax, groceries, water_light, travel_cost, cell_phone, other_expense, property);

    }

    public Program()
    {

    }


    List<float> expenditure = new List<float>();

    float rental_repayment = 0;



public void startCalculation(MenuControlProgram.PersonalBudget pb,float gross_monthly_income, float monthly_tax,float groceries,float water_light,float travel_cost,float cell_phone,float other_expense,int property)
    {

       
        
        expenditure.Add(groceries);
        expenditure.Add(water_light);
        expenditure.Add(travel_cost);
        expenditure.Add(cell_phone);
        expenditure.Add(other_expense);

        

        int mode = property;

        if (mode == 1)
        {
            if (rental_repayment == 0) {
                Rent r = new Rent(pb, gross_monthly_income, monthly_tax, groceries, water_light, travel_cost, cell_phone, other_expense, property);
                r.Show();
            }
            
          
            
           
        }
        else if (mode == 2)
        {



            if (rental_repayment == 0)
            {
                MenuControlProgram.HomeLoan hl_window = new MenuControlProgram.HomeLoan(pb, gross_monthly_income, monthly_tax, groceries, water_light, travel_cost, cell_phone, other_expense, property);
                hl_window.Show();
            }


        }


        float available_monthly_money = gross_monthly_income - monthly_tax - getTotalExpenditure(expenditure) - (rental_repayment);

        System.Windows.MessageBox.Show("Available Monthly Money : " + available_monthly_money);
    }






    public void vehicleCalculation(float gross_monthly_income,int mode,string model,float price,float deposit,float interest,float premium)
    {
        //calculating vehicle costs and listing expenses in descending order
        Vehicle v = new Vehicle(gross_monthly_income, expenditure, (rental_repayment),model,price,deposit,interest,premium);


    }



   public static float getTotalExpenditure(List<float> expenditure) //calculate sum of total expenditure
    {
        float sum = 0;
        foreach (float a in expenditure)
        {
            sum += a;
        }
        return sum;
    }

}