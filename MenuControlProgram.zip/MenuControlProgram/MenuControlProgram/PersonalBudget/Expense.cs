﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonalBudget //Parent class of homeloan
{
   abstract class Expense
    {

        //Abstract method to help calculate loan
        public abstract float calculateLoan(float gross_monthly_income);
        
    }
}
