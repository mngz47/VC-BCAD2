﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MenuControlProgram
{
    /// <summary>
    /// Interaction logic for HomeLoan.xaml
    /// </summary>
    public partial class HomeLoan : Window
    {



        MenuControlProgram.PersonalBudget pb;
        float gross_monthly_income;
        float monthly_tax;
        float groceries;
        float water_light;
        float travel_cost;
        float cell_phone;
        float other_expense;
        int property;


        public HomeLoan(MenuControlProgram.PersonalBudget pb, float gross_monthly_income, float monthly_tax, float groceries, float water_light, float travel_cost, float cell_phone, float other_expense, int property)
        {
            InitializeComponent();

            this.pb = pb;
            this.gross_monthly_income = gross_monthly_income;
            this.monthly_tax = monthly_tax;
            this.groceries = groceries;
            this.water_light = water_light;
            this.travel_cost = travel_cost;
            this.cell_phone = cell_phone;
            this.other_expense = other_expense;
            this.property = property;
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {


            float property_price = float.Parse(this.property_price.Text); 
            float property_deposit = float.Parse(this.property_deposit.Text);
            float property_interest = float.Parse(this.interest.Text);
            int property_repayment = Int32.Parse(this.repayment_months.Text);

            float repayment = calculateLoan2(gross_monthly_income, property_price, property_deposit, property_interest, property_repayment);


            Program p = new Program(pb,(repayment+""), gross_monthly_income, monthly_tax, groceries, water_light, travel_cost, cell_phone, other_expense, property);
            this.Close();

        }



        public float calculateLoan2(float gross_monthly_income, float property_price, float property_deposit, float interest, int repayment_months)
        { //Calculate loan monthly repayment



            float loan_repayment = ((property_price + property_deposit) * (1 + (interest / 100) * (repayment_months / 12))) / repayment_months;

            if (loan_repayment > (gross_monthly_income / 3))
            {
                System.Windows.MessageBox.Show("Approval of home loan unlikely");

            }
            return loan_repayment;
        }

    }
}
