﻿
using System.Windows;

namespace MenuControlProgram
{
    /// <summary>
    /// Interaction logic for Rent.xaml
    /// </summary>
    public partial class Rent : Window
    {

        MenuControlProgram.PersonalBudget pb;
        float gross_monthly_income;
        float monthly_tax; 
        float groceries;
        float water_light;
        float travel_cost; 
        float cell_phone;
        float other_expense;
        int property;


        public Rent(MenuControlProgram.PersonalBudget pb, float gross_monthly_income, float monthly_tax, float groceries, float water_light, float travel_cost, float cell_phone, float other_expense, int property)
        {
            InitializeComponent();

            this.pb = pb;
            this.gross_monthly_income = gross_monthly_income;
            this.monthly_tax = monthly_tax;
            this.groceries = groceries;
            this.water_light = water_light;
            this.travel_cost = travel_cost;
            this.cell_phone = cell_phone;
            this.other_expense = other_expense;
            this.property = property;
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {


            Program p = new Program(pb,this.rent_amount.Text, gross_monthly_income, monthly_tax, groceries, water_light, travel_cost, cell_phone, other_expense, property);
            this.Close();

        }


        }
}
