﻿using System;
using System.Windows;
namespace MenuControlProgram
{
    /// <summary>
    /// Interaction logic for Savings.xaml
    /// </summary>
    public partial class Savings : Window
    {
        public Savings()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                float amount = float.Parse(this.saving_amount.Text);
                int months = Int32.Parse(this.saving_months.Text);
                float interest = float.Parse(this.interest_rate.Text);

                //A = P(1+ (i * n))

                float monthly_saving = ((amount) / (1 + ((interest/100) * months)));

                MessageBox.Show("To save for " + this.reason_for_saving.Text + " within " + months + " month(S) you will need to put away R" + monthly_saving + " every month.");

            }
            catch (System.FormatException sfe)
            {
                MessageBox.Show("Check the format of the values you have inserted.");
            }
           
        }
    }
}
