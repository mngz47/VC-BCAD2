Personal Bugdet WPF
__________________
Version 3
________________________________

The purpose of the software is to manage income
Calculating Monthly Cost Of HomeLoan
Determine of you will qualify for a HomeLoan
Calculating Monthly Cost Vehicle
Find out the money left over after deductions
Calculate monthly cost of savings

__________________New features

Welcome page with menu
User interface with labels and textfields
Messagebox alert feature

______________________________________

Complile and run software.
_____________________________________

Unzip the program

Quick Run: Click Executable File in Bin folder

_______________________Debug

Open program using visual studio and click compile
This will generate list of errors while running the sofware
This will generate executable file in the bin folder of the program
The executable file can be used to run the program