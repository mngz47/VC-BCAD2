﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace StudyTimeManagement
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public MainWindow( List<DataSemester> dataSemesters)
        {
            InitializeComponent();
            this.dataSemesters = dataSemesters;
           
            if (this.dataSemesters!=null)
            {
                this._DATA_.ItemsSource = dataSemesters;
            }
        }

        List<DataSemester> dataSemesters = new List<DataSemester>();

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            DataSemester course = new DataSemester();
            course.name = course_name.Text;
            course.code = course_code.Text;
            course.credits = int.Parse(credits.Text);
            course.class_hours = int.Parse(class_hrs.Text);

            _DATA_.Items.Add(course);
            dataSemesters.Add(course);

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {


            Semester sem = new Semester(dataSemesters);
            sem.Show();
            this.Close();


        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void course_code_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
