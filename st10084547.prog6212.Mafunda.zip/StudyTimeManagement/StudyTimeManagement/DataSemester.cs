﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StudyTimeManagement
{
    public partial class DataSemester
    {


        public string code { get; set; }

        public string name { get; set; }

        public int credits { get; set; }

        public int class_hours { get; set; }

        public int self_study_hours { get; set; }

        public int rem_study_hours { get; set; }

    }
}
