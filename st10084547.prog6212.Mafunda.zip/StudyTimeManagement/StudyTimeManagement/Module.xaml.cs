﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace StudyTimeManagement
{
    /// <summary>
    /// Interaction logic for Module.xaml
    /// </summary>
    public partial class Module : Window
    {
        public Module()
        {
            InitializeComponent();
        }

        List<DataSemester> dataSemesters;

        public Module(List<DataSemester> dataSemesters)
        {
            InitializeComponent();
            //_DATA_ = dg;
            this.dataSemesters = dataSemesters;
            this._DATA_.ItemsSource = dataSemesters;

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow land = new MainWindow( dataSemesters);
            land.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Semester land = new Semester( dataSemesters);
            land.Show();
            this.Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {

            // calculate remaining study hours

            

            foreach (var emp in dataSemesters)
            {
                if (module_name.Text.Equals(emp.name))
                {
                    emp.rem_study_hours = emp.self_study_hours - int.Parse(module_hours.Text);
                    MessageBox.Show("remaining study hours: " + dataSemesters[0].rem_study_hours);
                }
            }

            //---------------

            this._DATA_.ItemsSource = dataSemesters;

        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
