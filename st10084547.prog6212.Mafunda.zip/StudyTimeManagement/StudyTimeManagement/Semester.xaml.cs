﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace StudyTimeManagement
{
    /// <summary>
    /// Interaction logic for Semester.xaml
    /// </summary>
    public partial class Semester : Window
    {
        public Semester()
        {
            InitializeComponent();
        }

        List<DataSemester> dataSemesters;

        public Semester(List<DataSemester> dataSemesters)
        {
            InitializeComponent();
            this.dataSemesters = dataSemesters;
            this._DATA_.ItemsSource = dataSemesters;

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow land = new MainWindow(dataSemesters);
            land.Show();
            this.Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Module land = new Module(dataSemesters);
            land.Show();
            this.Close();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {

            // calculate self study hours

            int n_of_w = int.Parse(number_of_weeks.Text);

           for(int a=0;a<dataSemesters.Count;a++)
            {
                dataSemesters[a].self_study_hours = (dataSemesters[a].credits * 10 / n_of_w) - dataSemesters[a].class_hours;
                MessageBox.Show("self study hours: " + dataSemesters[0].self_study_hours);
            }

            
 
            //---------------

             this._DATA_.ItemsSource = dataSemesters;

        }
    }
}
