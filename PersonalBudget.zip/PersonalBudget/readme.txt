Complile and run software.
_____________________________________

Unzip the program

Open program using visual studio and click compile

This will generate executable file in the bin folder of the program

The executable file can be used to run the program