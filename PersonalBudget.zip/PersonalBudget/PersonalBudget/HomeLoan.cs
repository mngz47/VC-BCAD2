﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonalBudget
{
     class HomeLoan : Expense
    {

        

         public override float calculateLoan(float gross_monthly_income)
        {

            float loan_repayment = 0;
            Console.WriteLine("Purchase price of the property");
            float property_price = float.Parse(Console.ReadLine());
            Console.WriteLine("Total deposit");
            float property_deposit = float.Parse(Console.ReadLine());
            Console.WriteLine("Interest rate(%)");
            float interest = float.Parse(Console.ReadLine());
            Console.WriteLine("Number of months to repay");
            int repayment_months = Int32.Parse(Console.ReadLine());

            loan_repayment = ((property_price + property_deposit) * (1 + (interest / 100) * (repayment_months / 12))) / repayment_months;

            if (loan_repayment > (gross_monthly_income / 3))
            {

                Console.WriteLine("Approval of home loan unlikely");

            }
            return loan_repayment;
        }


    }
}
