﻿using System;

public class Vehicle
{
	public	Vehicle(float income,List<float> expenditure,float loanRepayment)
	{

		Console.WriteLine("Buy a vehicle");
		Console.WriteLine("yes(1)");
		Console.WriteLine("no(2)");


		int mode = Console.ReadLine();

		if (mode == 1)
		{

			Console.WriteLine("Model and make");
			string model = Console.ReadLine();
			
			Console.WriteLine("Purchase price");
			float price = Console.ReadLine();
			Console.WriteLine("Total deposit");
			float deposit = Console.ReadLine();


			Console.WriteLine("Interest");
			float interest = Console.ReadLine();

			Console.WriteLine("Premium");
			float premium = Console.ReadLine();

			float tmc = totalMonthlyCost(price+deposit,interest/100);

            if (income*0.75<(expenditure.sum()+loanRepayment+tmc))
            {
				
				Del handler = DelegateMethod;
				handler("Total expenses exceed 75% of your income");

			}

			printExpenses(expenditure);
		}
	}

	public float totalMonthlyCost(float A,float i)
    {
		//A = P(1+ (i * n))
		return ((A) / (1+ (i * 5*12)));
	}

	public delegate void Del(string message);

	public static void DelegateMethod(string message)
	{
		Console.BackgroundColor = ConsoleColor.Blue;
		Console.WriteLine(message);
		Console.ResetColor();
	}


	public void printExpenses(List<float> expenditure)
    {

		Console.Writeline("Expenses in decsending order");
		expenditure.Sort();
		expenditure.Reverse();

		foreach (var item in expenditure)
        {
			Console.Writeline(item);
        }
    }



}