namespace LinqToXmlFileForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();


       

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {


            LinqToXmlObjectModel.InsertNewElement(txtMake.Text, txtColor.Text, txtPetName.Text);

        }

        private void button2_Click_1(object sender, EventArgs e)
        {

            LinqToXmlObjectModel.LookUpColorsForMake(txtMakeToLookUp.Text);

        }

        private void Form1_Load(object sender, EventArgs e)
        {

            // Display current XML inventory document in TextBox control. 

            txtInventory.Text = LinqToXmlObjectModel.GetXmlInventory().ToString();


        }
    }
}