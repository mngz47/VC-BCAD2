﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LinqTwo
{
    class Employee
    {


        public string FirstName { get; }
        public string LastName { get; }

        public int Score { get; }



       public Employee(string FirstName, string LastName, int Score)
        {

            this.FirstName = FirstName;
            this.LastName = LastName;
            this.Score = Score;

        }


    }
}
