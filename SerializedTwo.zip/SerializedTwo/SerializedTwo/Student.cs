﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SerializedTwo
{


    [Serializable]
    internal class Student
    {

        public int value = 0;
        public int value2 = 0;
        public string name = null;





    }
}
