﻿
using SerializedTwo;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

class Program
{
    static void Main(string[] arg )
    {
        Student s = new Student();
        s.value = 11;
        s.value2 = 22;
        s.name = "John Doe";


        IFormatter formatter = new BinaryFormatter();
        Stream stream = new FileStream("MyFile.bin", FileMode.Create ,FileAccess.Write,FileShare.None);
        formatter.Serialize(stream, s);
        stream.Close(); 
        // pass the stream into the binary formatter


        Stream stream1 = new FileStream("MyFile.bin", FileMode.Open, FileAccess.Read, FileShare.Read);
        Student s1 = (Student)formatter.Deserialize(stream1);
        stream1.Close();

        Console.WriteLine("value: {0}", s1.value);
        Console.WriteLine("value: {0}", s1.value2);
        Console.WriteLine("name: {0}", s1.name);

        Console.ReadLine();

    }


}





