﻿using System;

namespace Pointers
{
    class Program
    {
      

            static unsafe void Main(string[] args)

            {

                int val = 50;
                int* valPointer = &val;

                Console.WriteLine("Output");
                Console.WriteLine("Data: {0} ", val);
                Console.WriteLine("Address: {0} ", (int)valPointer);

                Console.ReadLine();

            }

    }
}
