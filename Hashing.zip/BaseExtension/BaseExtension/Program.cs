﻿using System;

namespace BaseExtension
{
    class Program
    {
        static void Main(string[] args)
        {

            /*
             *  Unit testing -- project stage
             *  add code onto existing projects
             *  without changing org form
             *  won't require any permissions from the org source
             *  inheritance extends whats already there
             *  You want to add something new
             *  You can't inherit from a sealed class
             *  if the org code is a struct and not a class
             *  
             *  EXTENSION METHODS
             * 
             */


       
            Program p = new Program();

            p.methodOne();
            p.methodTwo();


        }

        //Methods



        public void methodOne()
        {
            Console.WriteLine("From method one >>>");
        }

        public void methodTwo()
        {
            Console.WriteLine("From method two >>>");
        }





    }
}
