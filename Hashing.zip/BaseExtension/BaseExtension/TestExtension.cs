﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BaseExtension
{
    class TestExtension
    {


        static void Main(string[] args)
        {

            /*
             *  Unit testing -- project stage
             *  add code onto existing projects
             *  without changing org form
             *  won't require any permissions from the org source
             *  inheritance extends whats already there
             *  You want to add something new
             *  You can't inherit from a sealed class
             *  if the org code is a struct and not a class
             *  
             *  EXTENSION METHODS
             * 
             */



            Program p = new Program();

            p.methodOne();
            p.methodTwo();
            p.methodThree();

            Console.ReadLine();


        }


    }
}
