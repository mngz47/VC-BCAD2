﻿using System;

namespace LinqTwo
{
    class Program
    {
        static void Main(string[] args)
        {
            var employees = new[]
            {

                new Employee("Jason","Red",50000),
                new Employee("Ashley","Blue",50000),
                new Employee("Matthew","Green",50000),
                new Employee("James","Orange",50000)

            };


            // Linq
            Console.WriteLine("The org collection >>>>");
            foreach(var element in employees)
            {
                Console.WriteLine(element);
            }
            //order the employess last na,e && firstname

            var nameSorted = from e in employees orderby  e.LastName, e.FirstName select e;


            Console.WriteLine("Sorted by Name >>>>");
           
            foreach (var element in nameSorted)
            {
                Console.WriteLine(element);
            }
            //full names --> linq fn + ln

            var names = from e in employees select new { e.FirstName, e.LastName };

            foreach (var element in names)
            {
                Console.WriteLine(element);
            }


            Console.ReadLine();

        }
    }
}
