﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BaseExtension
{
   static class ExtensionClass
    {


        /* Extension
         * Must be in its own class
         * the classes must be static
         * the methods are static as well
         * then a ref parameter to the org base class
         * 
         * 
         * 
         */

        public static void methodThree(this Program prog)
        {

            Console.WriteLine("From extension methods >>>");

        }


    }
}
